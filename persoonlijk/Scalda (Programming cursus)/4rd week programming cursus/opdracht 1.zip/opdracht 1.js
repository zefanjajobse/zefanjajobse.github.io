/**
 * check welk type koek het is
 */
let koek = "kokosmakroon";
let uitslag = "";
if (koek == "kokosmakroon") {
    uitslag = "kokosmakroon"
} else if (koek == "eierkoek") {
    uitslag = "eierkoek"
} else if (koek == "koffiekoek") {
    uitslag = "koffiekoek"
} else if (koek == "vulkoek") {
    uitslag = "vulkoek"
} else if (koek == "boterkoek") {
    uitslg = "boterkoek"
}
console.log("het type koek is " + uitslag);
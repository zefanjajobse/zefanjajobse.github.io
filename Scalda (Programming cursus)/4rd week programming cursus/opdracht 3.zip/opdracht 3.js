let number1 = prompt('give the first number');
let number2 = prompt('give the second number');
alert("the first number is " + (number1 / number2) + " times as large as the second");